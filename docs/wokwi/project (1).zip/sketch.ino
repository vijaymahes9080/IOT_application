#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "DHT.h"

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_SDA 21
#define OLED_SCL 22

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

#define DHTPIN 4
#define DHTTYPE DHT22
#define SOIL_PIN 34
#define LIGHT_PIN 35
#define TRIG 5
#define ECHO 18

#define LED_PIN 2
#define BUZZER_PIN 15

DHT dht(DHTPIN, DHTTYPE);

// Simulated Satellite Position
float latitude = 13.0827;
float longitude = 80.2707;

void collisionAlert(float distance) {
  if (distance < 5 && distance > 0) {
    tone(BUZZER_PIN, 2000);   // continuous high alert
  }
  else if (distance < 20) {
    tone(BUZZER_PIN, 1500);
    delay(150);
    noTone(BUZZER_PIN);
    delay(150);
  }
  else if (distance < 40) {
    tone(BUZZER_PIN, 1000);
    delay(300);
    noTone(BUZZER_PIN);
    delay(300);
  }
  else {
    noTone(BUZZER_PIN);
  }
}

float readDistance() {
  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long duration = pulseIn(ECHO, HIGH);
  return duration * 0.034 / 2;
}

void setup() {
  Serial.begin(115200);

  Wire.begin(OLED_SDA, OLED_SCL);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED Failed");
    while (true);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);

  dht.begin();

  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
}

void loop() {

  // Simulated satellite orbit movement
  latitude += 0.0005;
  longitude += 0.0005;

  float temp = dht.readTemperature();
  float hum = dht.readHumidity();
  int soil = analogRead(SOIL_PIN);
  int light = analogRead(LIGHT_PIN);
  float distance = readDistance();

  bool irrigation = (soil < 1800 && light > 2000);
  bool collision = (distance < 25 && distance > 0);

  // LED control
  digitalWrite(LED_PIN, collision ? HIGH : LOW);

  // Smart Buzzer
  collisionAlert(distance);

  // OLED Display
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("SAT-AGRO LINK V3");
  display.println("----------------");
  display.print("Lat: "); display.println(latitude,4);
  display.print("Lng: "); display.println(longitude,4);
  display.print("Temp: "); display.println(temp);
  display.print("Hum : "); display.println(hum);
  display.print("Soil: "); display.println(soil);
  display.print("Dist: "); display.println(distance);

  if (collision)
    display.println("Collision ALERT!");
  else
    display.println("Safe Orbit");

  display.display();

  // Simulated LoRa Telemetry Packet
  Serial.println("===== LoRa TX Packet =====");
  Serial.print("Latitude: "); Serial.println(latitude,6);
  Serial.print("Longitude: "); Serial.println(longitude,6);
  Serial.print("Temperature: "); Serial.println(temp);
  Serial.print("Humidity: "); Serial.println(hum);
  Serial.print("Soil: "); Serial.println(soil);
  Serial.print("Light: "); Serial.println(light);
  Serial.print("Distance: "); Serial.println(distance);
  Serial.print("Irrigation: "); Serial.println(irrigation ? "ON" : "OFF");
  Serial.print("Collision: "); Serial.println(collision ? "YES" : "NO");
  Serial.println("==========================");

  delay(2000);
}