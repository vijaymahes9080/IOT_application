#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "DHT.h"

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

#define DHTPIN 4
#define DHTTYPE DHT22
#define SOIL_PIN 34
#define LIGHT_PIN 35

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  dht.begin();

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED Failed");
    while(true);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
}

void loop() {

  // ===== Read Sensors =====
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();
  int soilRaw = analogRead(SOIL_PIN);
  int lightRaw = analogRead(LIGHT_PIN);

  // Convert soil to percentage
  int soilPercent = map(soilRaw, 0, 4095, 0, 100);

  // Convert light to percentage
  int lightPercent = map(lightRaw, 0, 4095, 0, 100);

  // ===== Irrigation Logic =====
  bool irrigation = false;

  // Soil below 40% = dry
  if (soilPercent < 40) {
    irrigation = true;
  }

  // ===== OLED DISPLAY =====
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("SMART AGRO SAT");
  display.println("----------------");
  display.print("Temp : "); display.print(temp); display.println(" C");
  display.print("Hum  : "); display.print(hum); display.println(" %");
  display.print("Soil : "); display.print(soilPercent); display.println(" %");
  display.print("Light: "); display.print(lightPercent); display.println(" %");

  if (irrigation) {
    display.println("Irrigation: ON");
  } else {
    display.println("Irrigation: OFF");
  }

  display.display();

  // ===== Serial Telemetry =====
  Serial.println("===== SATELLITE TELEMETRY =====");
  Serial.print("Temperature: "); Serial.println(temp);
  Serial.print("Humidity   : "); Serial.println(hum);
  Serial.print("Soil %     : "); Serial.println(soilPercent);
  Serial.print("Light %    : "); Serial.println(lightPercent);
  Serial.print("Irrigation : ");
  Serial.println(irrigation ? "ON" : "OFF");
  Serial.println("===============================");
  Serial.println();

  delay(2000);
}